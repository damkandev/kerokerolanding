// Default settings
const DEFAULT_SETTINGS = {
    erMeterEnabled: true,
    debugHudEnabled: false
};

const SCHEDULED_POSTS_KEY = 'kinkedin_scheduled_posts';

// Load settings from storage and update UI
async function loadSettings() {
    const result = await chrome.storage.sync.get(DEFAULT_SETTINGS);

    document.getElementById('toggle-er-meter').checked = result.erMeterEnabled;
    document.getElementById('toggle-debug-hud').checked = result.debugHudEnabled;
}

// Save settings to storage
async function saveSettings() {
    const settings = {
        erMeterEnabled: document.getElementById('toggle-er-meter').checked,
        debugHudEnabled: document.getElementById('toggle-debug-hud').checked
    };

    await chrome.storage.sync.set(settings);

    // Notify content script of changes
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATED', settings });
    }
}

// Load and display scheduled posts
async function loadPosts() {
    const result = await chrome.storage.local.get(SCHEDULED_POSTS_KEY);
    const posts = result[SCHEDULED_POSTS_KEY] || [];
    const container = document.getElementById('posts-list');

    if (posts.length === 0) {
        container.innerHTML = '<span class="posts-empty">No hay posts guardados</span>';
        return;
    }

    container.innerHTML = posts.map(post => {
        const date = new Date(post.date);
        const dateStr = date.toLocaleDateString('es-CL', {
            weekday: 'short',
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
        const preview = (post.preview || 'Post sin preview').substring(0, 30);

        return `
            <div class="post-item" data-id="${post.id}">
                <div class="post-info">
                    <span class="post-date">${dateStr}</span>
                    <span class="post-preview">${preview}...</span>
                </div>
                <button class="delete-post-btn" data-id="${post.id}" title="Eliminar">×</button>
            </div>
        `;
    }).join('');

    // Add delete handlers
    container.querySelectorAll('.delete-post-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const id = e.target.dataset.id;
            await deletePost(id);
            loadPosts();
        });
    });
}

// Delete a single post
async function deletePost(postId) {
    const result = await chrome.storage.local.get(SCHEDULED_POSTS_KEY);
    const posts = result[SCHEDULED_POSTS_KEY] || [];
    const filtered = posts.filter(p => p.id !== postId);
    await chrome.storage.local.set({ [SCHEDULED_POSTS_KEY]: filtered });
}

// Clear all posts
async function clearAllPosts() {
    if (confirm('¿Eliminar todos los posts guardados?')) {
        await chrome.storage.local.set({ [SCHEDULED_POSTS_KEY]: [] });
        loadPosts();
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    loadPosts();

    // Add event listeners for toggle switches
    document.getElementById('toggle-er-meter').addEventListener('change', saveSettings);
    document.getElementById('toggle-debug-hud').addEventListener('change', saveSettings);

    // Clear all posts button
    document.getElementById('clear-all-posts').addEventListener('click', clearAllPosts);
});
