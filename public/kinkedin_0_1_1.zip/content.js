console.log("Kinkedin v6 - With Scheduled Posts Calendar");

// --- Settings State ---
let settings = {
    erMeterEnabled: true,
    debugHudEnabled: false
};

// Load settings from storage on init
chrome.storage.sync.get(settings, (result) => {
    settings = result;
    console.log("Settings loaded:", settings);
});

// Listen for settings updates from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'SETTINGS_UPDATED') {
        settings = message.settings;
        console.log("Settings updated:", settings);

        // If ER meter is disabled, remove all existing badges
        if (!settings.erMeterEnabled) {
            document.querySelectorAll('.kinked-badges-container').forEach(el => el.remove());
        }
        // If debug HUD is disabled, remove all existing HUDs
        if (!settings.debugHudEnabled) {
            document.querySelectorAll('.kinked-debug-hud').forEach(el => el.remove());
        }

        // Re-scan if enabling features
        if (settings.erMeterEnabled || settings.debugHudEnabled) {
            scanExisting();
        }
    }
});

const OBSERVER_CONFIG = { childList: true, subtree: true };
const FEED_SELECTOR = '.scaffold-finite-scroll__content';

// --- Regex Helpers ---
const IMPRESSIONS_REGEX = /(\d+(?:[.,]\d+)?)\s+impresiones/i;
const COMMENTS_REGEX = /(\d+(?:[.,]\d+)?)\s+(?:comentari|comment)/i;
const REPOSTS_REGEX = /(\d+(?:[.,]\d+)?)\s+(?:repost|compartid|veces compartid|share)/i;
const CLICKS_REGEX = /(\d+(?:[.,]\d+)?)\s+(?:clics?|clicks?)/i;

function cleanNumber(str) {
    if (!str) return 0;
    // Match a number that may have dots/commas as thousand separators
    // Pattern: one or more digits, optionally followed by (dot or comma + digits) groups
    // Examples: "13.777", "1,234", "13", "1.234.567"
    const match = String(str).match(/[\d]+(?:[.,]\d{3})*/);
    if (!match) return 0;
    // Remove the separators to get the raw number
    return parseInt(match[0].replace(/[.,]/g, ''), 10);
}

function findNumberByRegexInNode(node, regex) {
    const els = Array.from(node.querySelectorAll('.social-details-social-counts__count-value, .social-details-social-counts__btn, button, a, span, div'));
    for (const el of els) {
        const t = (el.textContent || '').trim();
        const m = t.match(regex);
        if (m) return cleanNumber(m[1]);
    }
    return 0;
}

function getPostAgeHours(postNode) {
    const timeEl = postNode.querySelector('time[datetime]');
    if (!timeEl) return null;
    const dt = new Date(timeEl.getAttribute('datetime'));
    if (Number.isNaN(dt.getTime())) return null;
    const now = new Date();
    const diffMs = now - dt;
    return Math.max(diffMs / (1000 * 60 * 60), 0.01);
}

function expectedERByAgeHours(ageH) {
    if (ageH < 2) return 0.6;
    if (ageH < 12) return 1.2;
    if (ageH < 48) return 1.8;
    if (ageH < 168) return 2.2;
    return 1.8;
}

function labelByER(er) {
    if (er < 0.5) return {
        label: 'Muy bajo',
        cls: 'kinked-health-muy-bajo',
        explanation: `Tu ER es ${er.toFixed(2)}% (< 0.5%). El contenido no conecta, LinkedIn casi no lo distribuye.`
    };
    if (er < 1) return {
        label: 'Bajo',
        cls: 'kinked-health-bajo',
        explanation: `Tu ER es ${er.toFixed(2)}% (0.5-1%). Interacción débil, común en contenido genérico o muy corporativo.`
    };
    if (er < 2.5) return {
        label: 'Sano',
        cls: 'kinked-health-sano',
        explanation: `Tu ER es ${er.toFixed(2)}% (1-2.5%). Buen rendimiento normal, el post funciona correctamente.`
    };
    if (er < 5) return {
        label: 'Alto',
        cls: 'kinked-health-alto',
        explanation: `Tu ER es ${er.toFixed(2)}% (2.5-5%). Muy buen post, LinkedIn empieza a empujarlo más allá de tu red.`
    };
    if (er < 8) return {
        label: 'Excelente',
        cls: 'kinked-health-excelente',
        explanation: `Tu ER es ${er.toFixed(2)}% (5-8%). Contenido destacado, genera conversación real.`
    };
    if (er < 12) return {
        label: 'Viral',
        cls: 'kinked-health-viral',
        explanation: `Tu ER es ${er.toFixed(2)}% (8-12%). Alto alcance, comentarios y compartidos dominan.`
    };
    return {
        label: 'Ultra viral',
        cls: 'kinked-health-ultra-viral',
        explanation: `Tu ER es ${er.toFixed(2)}% (> 12%). Caso raro, fuerte identificación emocional y timing perfecto.`
    };
}

function updateDebugHUD(postNode, stats) {
    // Remove HUD if disabled
    if (!settings.debugHudEnabled) {
        const existing = postNode.querySelector('.kinked-debug-hud');
        if (existing) existing.remove();
        return;
    }

    let hud = postNode.querySelector('.kinked-debug-hud');
    if (!hud) {
        hud = document.createElement('div');
        hud.className = 'kinked-debug-hud';
        if (getComputedStyle(postNode).position === 'static') {
            postNode.style.position = 'relative';
        }
        postNode.appendChild(hud);
    }

    hud.innerText = `Imp: ${stats.impressions}
Rea: ${stats.reactions} | Com: ${stats.comments}
Rep: ${stats.reposts} | Clk: ${stats.clicks}
Tot: ${stats.total}
Age: ${stats.ageH ? stats.ageH.toFixed(1) + 'h' : '?'}
ER: ${stats.er.toFixed(2)}%`;
}

function processPost(postNode) {
    // Skip if ER meter is disabled
    if (!settings.erMeterEnabled && !settings.debugHudEnabled) return;

    // 1. Impressions
    const analyticsEl = postNode.querySelector('.analytics-entry-point')
        || Array.from(postNode.querySelectorAll('a, span, div, strong'))
            .find(el => (el.textContent || '').toLowerCase().includes('impresiones'));

    if (!analyticsEl) return;

    const impressionsMatch = (analyticsEl.textContent || '').match(IMPRESSIONS_REGEX);
    if (!impressionsMatch) return;
    const impressions = cleanNumber(impressionsMatch[1]);
    if (!impressions) return;

    // 2. REACTIONS - Fixed Strategy
    // LinkedIn puts the raw count in .social-details-social-counts__social-proof-fallback-number
    // This element contains just "13" without the "Emerson y 12 personas más" text

    let reactions = 0;

    // Method A: Use the specific fallback number span (most reliable)
    const fallbackNumberEl = postNode.querySelector('.social-details-social-counts__social-proof-fallback-number');
    if (fallbackNumberEl) {
        reactions = cleanNumber(fallbackNumberEl.textContent);
    } else {
        // Method B: Try old explicit class
        const reactElExplicit = postNode.querySelector('.social-details-social-counts__reactions-count, [data-test-id="social-actions__reaction-count"]');
        if (reactElExplicit) {
            reactions = cleanNumber(reactElExplicit.textContent);
        } else {
            // Method C: Fallback heuristic - find count-value that is NOT comments/reposts
            // But ONLY take the first number from it
            const countValues = Array.from(postNode.querySelectorAll('.social-details-social-counts__count-value'));
            const reactionCandidates = countValues.filter(el => {
                const t = (el.textContent || '').toLowerCase();
                return !t.includes('comentari') && !t.includes('comment') && !t.includes('repost') && !t.includes('compartid') && !t.includes('share');
            });

            if (reactionCandidates.length > 0) {
                // cleanNumber now only takes first digit sequence
                reactions = cleanNumber(reactionCandidates[0].textContent);
            }
        }
    }

    const comments = findNumberByRegexInNode(postNode, COMMENTS_REGEX);
    const reposts = findNumberByRegexInNode(postNode, REPOSTS_REGEX);
    const clicks = findNumberByRegexInNode(postNode, CLICKS_REGEX);

    const totalInteractions = reactions + comments + reposts + clicks;
    const er = (totalInteractions / impressions) * 100;
    const ageH = getPostAgeHours(postNode);

    // Debug Data
    const stats = { impressions, reactions, comments, reposts, clicks, total: totalInteractions, er, ageH };
    updateDebugHUD(postNode, stats);

    // 3. Normalization & Badges
    let normalized = null;
    if (ageH != null) {
        const expected = expectedERByAgeHours(ageH);
        normalized = (er / expected) * 100;
    }

    const { label, cls, explanation } = labelByER(er);

    // Skip badge rendering if ER meter is disabled
    if (!settings.erMeterEnabled) return;

    const oldContainer = postNode.querySelector('.kinked-badges-container');
    if (oldContainer) oldContainer.remove();

    const container = document.createElement('div');
    container.className = 'kinked-badges-container';

    const rateBadge = document.createElement('div');
    rateBadge.className = 'kinked-analytics-badge';
    rateBadge.innerText = `${er.toFixed(2)}% conv.`;
    rateBadge.title = `R:${reactions} C:${comments} S:${reposts} Clk:${clicks}`;

    const healthBadge = document.createElement('div');
    healthBadge.className = `kinked-health-badge ${cls}`;
    healthBadge.innerText = label;

    // Help badge with "?" and explanation
    const helpBadge = document.createElement('div');
    helpBadge.className = 'kinked-help-badge';
    helpBadge.innerText = '?';
    helpBadge.title = explanation;

    container.appendChild(rateBadge);
    container.appendChild(healthBadge);
    container.appendChild(helpBadge);

    if (normalized != null) {
        const normBadge = document.createElement('div');
        normBadge.className = 'kinked-analytics-badge';
        normBadge.innerText = `${normalized.toFixed(0)}% vs t`;
        normBadge.title = `Normalizado por tiempo (~${ageH.toFixed(1)}h)`;
        container.appendChild(normBadge);
    }

    const textContainer = postNode.querySelector('.feed-shared-update-v2__description, .update-components-text-view, .update-components-text');
    if (textContainer) {
        textContainer.parentElement.insertBefore(container, textContainer);
    } else {
        const header = postNode.querySelector('.update-components-actor, .feed-shared-actor');
        if (header && header.parentElement) {
            header.parentElement.insertBefore(container, header.nextSibling);
        } else {
            postNode.prepend(container);
        }
    }
}

// --- Throttle & Batch Processing ---
// Cache para posts ya procesados (evita reprocesamiento costoso)
const processedPostsCache = new WeakSet();
let scanScheduled = false;
let lastScanTime = 0;
const SCAN_THROTTLE_MS = 500; // Mínimo 500ms entre escaneos
const BATCH_SIZE = 3; // Procesar 3 posts a la vez
const BATCH_DELAY_MS = 50; // Delay entre lotes

function handleMutations(mutations) {
    let shouldScan = false;
    for (const m of mutations) {
        if (m.addedNodes.length > 0) {
            shouldScan = true;
            break;
        }
    }
    if (shouldScan) scheduleScan();
}

// Programar escaneo con throttling
function scheduleScan() {
    if (scanScheduled) return;

    const now = Date.now();
    const timeSinceLastScan = now - lastScanTime;

    if (timeSinceLastScan >= SCAN_THROTTLE_MS) {
        // Suficiente tiempo ha pasado, escanear inmediatamente
        performScan();
    } else {
        // Esperar hasta que se cumpla el throttle
        scanScheduled = true;
        setTimeout(() => {
            scanScheduled = false;
            performScan();
        }, SCAN_THROTTLE_MS - timeSinceLastScan);
    }
}

function performScan() {
    lastScanTime = Date.now();
    const posts = Array.from(document.querySelectorAll('.feed-shared-update-v2, [data-urn]'));

    // Filtrar posts que ya fueron procesados (y no cambiaron)
    const postsToProcess = posts.filter(post => {
        // Verificar si ya tiene badges (procesado exitoso anterior)
        if (processedPostsCache.has(post)) {
            // Si ya tiene badges, no re-procesar a menos que no tenga ninguno
            const hasBadge = post.querySelector('.kinked-badges-container');
            if (hasBadge) return false;
        }
        return true;
    });

    if (postsToProcess.length === 0) return;

    // Procesar en lotes para no bloquear el hilo principal
    processBatch(postsToProcess, 0);
}

function processBatch(posts, startIndex) {
    const endIndex = Math.min(startIndex + BATCH_SIZE, posts.length);

    // Usar requestIdleCallback si está disponible, sino setTimeout
    const scheduleNext = (callback) => {
        if (window.requestIdleCallback) {
            requestIdleCallback(callback, { timeout: 100 });
        } else {
            setTimeout(callback, BATCH_DELAY_MS);
        }
    };

    // Procesar el lote actual
    for (let i = startIndex; i < endIndex; i++) {
        const post = posts[i];
        try {
            processPost(post);
            processedPostsCache.add(post);
        } catch (e) {
            console.warn('Kinkedin: Error processing post', e);
        }
    }

    // Programar siguiente lote si hay más posts
    if (endIndex < posts.length) {
        scheduleNext(() => processBatch(posts, endIndex));
    }
}

// Función legacy para compatibilidad
function scanExisting() {
    scheduleScan();
}

const observer = new MutationObserver(handleMutations);
const target = document.querySelector(FEED_SELECTOR) || document.body;
observer.observe(target, OBSERVER_CONFIG);

// Escaneo periódico menos agresivo (cada 2 segundos en lugar de 1)
setInterval(scheduleScan, 2000);

// Initialize Calendar Module (from calendar.js)
if (window.kinkedinCalendar) {
    window.kinkedinCalendar.init();
    console.log('Kinkedin: Calendar module connected');
}
