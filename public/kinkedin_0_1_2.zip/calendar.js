/**
 * Kinkedin - Scheduled Posts Calendar Module
 * Handles detection of scheduled posts and calendar UI
 */

// Storage key for scheduled posts
const SCHEDULED_POSTS_KEY = 'kinkedin_scheduled_posts';

// --- Extension Context Validity for Calendar Module ---
let calendarExtensionContextValid = true;

// Check if extension context is still valid
function isCalendarExtensionContextValid() {
    try {
        return chrome.runtime?.id != null;
    } catch (e) {
        return false;
    }
}

// Handle context invalidation
function handleCalendarContextInvalidated() {
    if (!calendarExtensionContextValid) return;
    calendarExtensionContextValid = false;
    console.warn('Kinkedin Calendar: Extension context invalidated');
}

// Toast notification system
function showToast(message, type = 'success') {
    // Remove existing toast
    const existing = document.querySelector('.kinked-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `kinked-toast kinked-toast-${type}`;
    toast.innerHTML = `
        <span class="kinked-toast-icon">${type === 'success' ? '✅' : 'ℹ️'}</span>
        <span class="kinked-toast-message">${message}</span>
    `;

    document.body.appendChild(toast);

    // Animate in
    requestAnimationFrame(() => {
        toast.classList.add('kinked-toast-visible');
    });

    // Auto remove after 4s
    setTimeout(() => {
        toast.classList.remove('kinked-toast-visible');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Get scheduled posts from storage
async function getScheduledPosts() {
    // Check context first
    if (!isCalendarExtensionContextValid()) {
        handleCalendarContextInvalidated();
        return [];
    }

    try {
        const result = await chrome.storage.local.get(SCHEDULED_POSTS_KEY);
        return result[SCHEDULED_POSTS_KEY] || [];
    } catch (e) {
        console.error('Kinkedin: Storage error', e);
        if (e.message?.includes('Extension context invalidated')) {
            handleCalendarContextInvalidated();
            showToast('⚠️ Recarga la página para usar Kinkedin', 'info');
        }
        return [];
    }
}

// Save scheduled posts to storage
async function saveScheduledPosts(posts) {
    // Check context first
    if (!isCalendarExtensionContextValid()) {
        handleCalendarContextInvalidated();
        return;
    }

    try {
        await chrome.storage.local.set({ [SCHEDULED_POSTS_KEY]: posts });
    } catch (e) {
        console.error('Kinkedin: Storage save error', e);
        if (e.message?.includes('Extension context invalidated')) {
            handleCalendarContextInvalidated();
            showToast('⚠️ Recarga la página para usar Kinkedin', 'info');
        }
    }
}

// Add a new scheduled post
async function addScheduledPost(post) {
    try {
        const posts = await getScheduledPosts();
        posts.push({
            id: Date.now().toString(),
            ...post,
            createdAt: new Date().toISOString()
        });
        await saveScheduledPosts(posts);
        console.log('Kinkedin: Scheduled post saved', post);

        // Show toast notification
        const previewText = post.preview ? post.preview.substring(0, 30) + '...' : 'Post';
        showToast(`📅 ${previewText} añadido al calendario`);
    } catch (e) {
        console.error('Kinkedin: Add post error', e);
    }
}

// Delete a scheduled post
async function deleteScheduledPost(postId) {
    try {
        const posts = await getScheduledPosts();
        const filtered = posts.filter(p => p.id !== postId);
        await saveScheduledPosts(filtered);
    } catch (e) {
        console.error('Kinkedin: Delete post error', e);
    }
}

// Heatmap data - best posting hours (based on general LinkedIn engagement data)
// Values 0-100 representing relative engagement
const HEATMAP_DATA = {
    // Hour: [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
    6: [15, 18, 16, 17, 14, 8, 6],
    7: [25, 28, 26, 27, 22, 12, 10],
    8: [45, 52, 48, 50, 40, 18, 15],
    9: [65, 72, 68, 70, 55, 22, 18],
    10: [80, 88, 85, 86, 70, 28, 22],
    11: [90, 96, 92, 94, 78, 32, 26],
    12: [75, 82, 78, 80, 65, 28, 22],
    13: [70, 78, 74, 76, 60, 25, 20],
    14: [55, 62, 58, 60, 48, 20, 16],
    15: [50, 56, 52, 54, 42, 18, 14],
    16: [48, 54, 50, 52, 40, 16, 12],
    17: [52, 58, 54, 56, 45, 18, 14],
    18: [55, 62, 58, 60, 48, 20, 16],
    19: [50, 56, 52, 54, 42, 18, 14],
    20: [40, 45, 42, 44, 35, 15, 12],
    21: [30, 34, 32, 33, 26, 12, 10],
    22: [20, 22, 21, 22, 18, 8, 7],
    23: [12, 14, 13, 14, 10, 5, 4]
};

function getHeatmapColor(value) {
    // LinkedIn blue gradient: lighter (low engagement) to darker (high engagement)
    const minColor = { r: 240, g: 245, b: 255 }; // Very light blue
    const maxColor = { r: 10, g: 102, b: 194 };  // LinkedIn blue

    const ratio = value / 100;
    const r = Math.round(minColor.r + (maxColor.r - minColor.r) * ratio);
    const g = Math.round(minColor.g + (maxColor.g - minColor.g) * ratio);
    const b = Math.round(minColor.b + (maxColor.b - minColor.b) * ratio);

    return `rgb(${r}, ${g}, ${b})`;
}

function getTextColor(value) {
    return value > 50 ? '#ffffff' : '#333333';
}

// Generate expanded 7-day calendar with hourly grid and heatmap
function generateCalendarHTML(posts) {
    const today = new Date();
    const days = [];
    const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const fullDayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

    for (let i = 0; i < 7; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        days.push({
            date: date,
            dayName: dayNames[date.getDay()],
            fullDayName: fullDayNames[date.getDay()],
            dayNum: date.getDate(),
            dayOfWeek: date.getDay(), // 0=Sun, 1=Mon, etc.
            isToday: i === 0
        });
    }

    // Build posts map by day and hour
    const postsMap = {};
    posts.forEach(p => {
        const postDate = new Date(p.date);
        const dayKey = postDate.toDateString();
        const hour = postDate.getHours();
        const key = `${dayKey}-${hour}`;
        if (!postsMap[key]) postsMap[key] = [];
        postsMap[key].push(p);
    });

    // Hours to show (6:00 - 23:00)
    const hours = [];
    for (let h = 6; h <= 23; h++) hours.push(h);

    // Generate header row
    const headerHTML = `
        <div class="kinked-heatmap-row kinked-heatmap-header">
            <div class="kinked-heatmap-hour-label"></div>
            ${days.map(d => `
                <div class="kinked-heatmap-day-header ${d.isToday ? 'kinked-heatmap-today' : ''}">
                    <span class="kinked-heatmap-day-name">${d.fullDayName}</span>
                    <span class="kinked-heatmap-day-num">${d.dayNum}</span>
                </div>
            `).join('')}
        </div>
    `;

    // Generate hour rows
    const rowsHTML = hours.map(hour => {
        const cellsHTML = days.map(day => {
            const dayKey = day.date.toDateString();
            const key = `${dayKey}-${hour}`;
            const cellPosts = postsMap[key] || [];

            // Get heatmap value for this hour/day
            const heatmapDayIndex = day.dayOfWeek === 0 ? 6 : day.dayOfWeek - 1; // Adjust for Mon=0
            const heatmapValue = HEATMAP_DATA[hour]?.[heatmapDayIndex] || 0;
            const bgColor = getHeatmapColor(heatmapValue);
            const textColor = getTextColor(heatmapValue);

            const hasPost = cellPosts.length > 0;
            const postIndicator = hasPost
                ? `<div class="kinked-heatmap-post-indicator" title="${cellPosts.map(p => p.preview || 'Post').join(', ')}">${cellPosts.length}</div>`
                : '';

            return `
                <div class="kinked-heatmap-cell ${hasPost ? 'kinked-heatmap-has-post' : ''}" 
                     style="background-color: ${bgColor}; color: ${textColor};"
                     title="${heatmapValue}% engagement">
                    <span class="kinked-heatmap-percent">${heatmapValue}%</span>
                    ${postIndicator}
                </div>
            `;
        }).join('');

        return `
            <div class="kinked-heatmap-row">
                <div class="kinked-heatmap-hour-label">${hour.toString().padStart(2, '0')}:00</div>
                ${cellsHTML}
            </div>
        `;
    }).join('');

    return `
        <div class="kinked-calendar-container kinked-calendar-expanded">
            <div class="kinked-calendar-header">
                <span class="kinked-calendar-title">📅 Calendario & Heatmap</span>
                <button class="kinked-calendar-close">×</button>
            </div>
            <div class="kinked-heatmap-wrapper">
                ${headerHTML}
                ${rowsHTML}
            </div>
            <div class="kinked-calendar-footer">
                <span class="kinked-calendar-legend">
                    <span class="kinked-legend-low">Bajo</span>
                    <span class="kinked-legend-bar"></span>
                    <span class="kinked-legend-high">Alto engagement</span>
                </span>
                <span class="kinked-calendar-count">${posts.length} post${posts.length !== 1 ? 's' : ''} programado${posts.length !== 1 ? 's' : ''}</span>
            </div>
        </div>
    `;
}

// Generate SIMPLE 7-day calendar HTML (posts only, no heatmap)
function generateSimpleCalendarHTML(posts) {
    const today = new Date();
    const days = [];
    const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    for (let i = 0; i < 7; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        days.push({
            date: date,
            dayName: dayNames[date.getDay()],
            dayNum: date.getDate(),
            isToday: i === 0
        });
    }

    const postsHTML = days.map(day => {
        const dayStart = new Date(day.date);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(day.date);
        dayEnd.setHours(23, 59, 59, 999);

        const dayPosts = posts.filter(p => {
            const postDate = new Date(p.date);
            return postDate >= dayStart && postDate <= dayEnd;
        });

        const postsBlocks = dayPosts.map(p => {
            const time = new Date(p.date).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
            return `<div class="kinked-simple-post" title="${p.preview || 'Post programado'}">
                <span class="kinked-simple-post-time">${time}</span>
                <span class="kinked-simple-post-preview">${(p.preview || 'Post').substring(0, 20)}...</span>
            </div>`;
        }).join('');

        return `
            <div class="kinked-simple-day ${day.isToday ? 'kinked-simple-today' : ''}">
                <div class="kinked-simple-day-header">
                    <span class="kinked-simple-day-name">${day.dayName}</span>
                    <span class="kinked-simple-day-num">${day.dayNum}</span>
                </div>
                <div class="kinked-simple-day-posts">
                    ${postsBlocks || '<span class="kinked-simple-empty">Sin posts</span>'}
                </div>
            </div>
        `;
    }).join('');

    return `
        <div class="kinked-simple-grid">
            ${postsHTML}
        </div>
        <div class="kinked-calendar-footer">
            <span class="kinked-calendar-count">${posts.length} post${posts.length !== 1 ? 's' : ''} programado${posts.length !== 1 ? 's' : ''}</span>
        </div>
    `;
}

// Current view preference
let calendarViewMode = 'simple'; // 'simple' or 'heatmap'

// Create and show calendar popup
async function showCalendarPopup(anchorElement) {
    // Remove existing popup if any
    const existing = document.querySelector('.kinked-calendar-popup');
    if (existing) {
        existing.remove();
        return; // Toggle behavior
    }

    const posts = await getScheduledPosts();

    const popup = document.createElement('div');
    popup.className = 'kinked-calendar-popup';

    // Build popup with toggle switch
    popup.innerHTML = `
        <div class="kinked-calendar-container ${calendarViewMode === 'heatmap' ? 'kinked-calendar-expanded' : ''}">
            <div class="kinked-calendar-header">
                <span class="kinked-calendar-title">📅 Posts Programados</span>
                <div class="kinked-view-toggle">
                    <span class="kinked-toggle-label">Heatmap</span>
                    <label class="kinked-switch">
                        <input type="checkbox" id="kinked-view-switch" ${calendarViewMode === 'heatmap' ? 'checked' : ''}>
                        <span class="kinked-slider"></span>
                    </label>
                </div>
                <button class="kinked-calendar-close">×</button>
            </div>
            <div class="kinked-calendar-body">
                ${calendarViewMode === 'heatmap' ? generateHeatmapContent(posts) : generateSimpleCalendarHTML(posts)}
            </div>
        </div>
    `;

    document.body.appendChild(popup);

    // Toggle switch handler
    const switchEl = popup.querySelector('#kinked-view-switch');
    switchEl.addEventListener('change', async () => {
        calendarViewMode = switchEl.checked ? 'heatmap' : 'simple';
        const container = popup.querySelector('.kinked-calendar-container');
        const body = popup.querySelector('.kinked-calendar-body');

        container.classList.toggle('kinked-calendar-expanded', calendarViewMode === 'heatmap');
        const freshPosts = await getScheduledPosts();
        body.innerHTML = calendarViewMode === 'heatmap'
            ? generateHeatmapContent(freshPosts)
            : generateSimpleCalendarHTML(freshPosts);
    });

    // Close button handler
    popup.querySelector('.kinked-calendar-close').addEventListener('click', () => {
        popup.remove();
    });

    // Close on outside click
    setTimeout(() => {
        document.addEventListener('click', function closePopup(e) {
            if (!popup.contains(e.target) && !anchorElement.contains(e.target)) {
                popup.remove();
                document.removeEventListener('click', closePopup);
            }
        });
    }, 100);
}

// Generate just the heatmap content (without container)
function generateHeatmapContent(posts) {
    const today = new Date();
    const days = [];
    const dayNames = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const fullDayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

    for (let i = 0; i < 7; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() + i);
        days.push({
            date: date,
            dayName: dayNames[date.getDay()],
            fullDayName: fullDayNames[date.getDay()],
            dayNum: date.getDate(),
            dayOfWeek: date.getDay(),
            isToday: i === 0
        });
    }

    const postsMap = {};
    posts.forEach(p => {
        const postDate = new Date(p.date);
        const dayKey = postDate.toDateString();
        const hour = postDate.getHours();
        const key = `${dayKey}-${hour}`;
        if (!postsMap[key]) postsMap[key] = [];
        postsMap[key].push(p);
    });

    const hours = [];
    for (let h = 6; h <= 23; h++) hours.push(h);

    const headerHTML = `
        <div class="kinked-heatmap-row kinked-heatmap-header">
            <div class="kinked-heatmap-hour-label"></div>
            ${days.map(d => `
                <div class="kinked-heatmap-day-header ${d.isToday ? 'kinked-heatmap-today' : ''}">
                    <span class="kinked-heatmap-day-name">${d.fullDayName}</span>
                    <span class="kinked-heatmap-day-num">${d.dayNum}</span>
                </div>
            `).join('')}
        </div>
    `;

    const rowsHTML = hours.map(hour => {
        const cellsHTML = days.map(day => {
            const dayKey = day.date.toDateString();
            const key = `${dayKey}-${hour}`;
            const cellPosts = postsMap[key] || [];

            const heatmapDayIndex = day.dayOfWeek === 0 ? 6 : day.dayOfWeek - 1;
            const heatmapValue = HEATMAP_DATA[hour]?.[heatmapDayIndex] || 0;
            const bgColor = getHeatmapColor(heatmapValue);
            const textColor = getTextColor(heatmapValue);

            const hasPost = cellPosts.length > 0;

            // Create card-style post display
            let postCard = '';
            if (hasPost) {
                const firstPost = cellPosts[0];
                const time = new Date(firstPost.date).toLocaleTimeString('es-CL', { hour: '2-digit', minute: '2-digit' });
                const preview = (firstPost.preview || 'Post').substring(0, 15);
                const moreCount = cellPosts.length > 1 ? `+${cellPosts.length - 1}` : '';
                postCard = `
                    <div class="kinked-heatmap-post-card" title="${cellPosts.map(p => p.preview || 'Post').join(' | ')}">
                        <span class="kinked-post-card-time">${time}</span>
                        <span class="kinked-post-card-preview">${preview}${moreCount ? ` ${moreCount}` : ''}</span>
                    </div>
                `;
            }

            return `
                <div class="kinked-heatmap-cell ${hasPost ? 'kinked-heatmap-has-post' : ''}" 
                     style="background-color: ${bgColor}; color: ${textColor};"
                     title="${heatmapValue}% engagement">
                    ${hasPost ? postCard : `<span class="kinked-heatmap-percent">${heatmapValue}%</span>`}
                </div>
            `;
        }).join('');

        return `
            <div class="kinked-heatmap-row">
                <div class="kinked-heatmap-hour-label">${hour.toString().padStart(2, '0')}:00</div>
                ${cellsHTML}
            </div>
        `;
    }).join('');

    return `
        <div class="kinked-heatmap-wrapper">
            ${headerHTML}
            ${rowsHTML}
        </div>
        <div class="kinked-calendar-footer">
            <span class="kinked-calendar-legend">
                <span class="kinked-legend-low">Bajo</span>
                <span class="kinked-legend-bar"></span>
                <span class="kinked-legend-high">Alto engagement</span>
            </span>
            <span class="kinked-calendar-count">${posts.length} post${posts.length !== 1 ? 's' : ''}</span>
        </div>
    `;
}

// Create calendar button to inject
function createCalendarButton() {
    const btn = document.createElement('button');
    btn.className = 'kinked-calendar-btn artdeco-button artdeco-button--circle artdeco-button--muted artdeco-button--2 artdeco-button--tertiary';
    btn.setAttribute('aria-label', 'Ver calendario de posts');
    btn.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="16" y1="2" x2="16" y2="6"></line>
            <line x1="8" y1="2" x2="8" y2="6"></line>
            <line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
    `;
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        showCalendarPopup(btn);
    });
    return btn;
}

// Observe the modal for scheduling actions
let calendarModalObserver = null;

function observeSchedulingModal() {
    calendarModalObserver = new MutationObserver((mutations) => {
        // Stop if context is invalid
        if (!calendarExtensionContextValid) {
            calendarModalObserver.disconnect();
            return;
        }

        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === 1) {
                    // Check if this is the post modal
                    if (node.classList?.contains('artdeco-modal') || node.querySelector?.('.artdeco-modal')) {
                        const modal = node.classList?.contains('artdeco-modal') ? node : node.querySelector('.artdeco-modal');
                        if (modal) {
                            // Check if it's the scheduled posts LIST modal
                            if (modal.textContent?.includes('Publicaciones programadas') ||
                                modal.textContent?.includes('Scheduled posts')) {
                                console.log('Kinkedin: Scheduled posts list modal detected');
                                importScheduledPostsFromModal(modal);
                            } else {
                                handleModalAppeared(modal);
                            }
                        }
                    }
                }
            }
        }
    });

    calendarModalObserver.observe(document.body, { childList: true, subtree: true });
}

// Import existing scheduled posts from LinkedIn's modal
async function importScheduledPostsFromModal(modal) {
    console.log('Kinkedin: Importing scheduled posts from LinkedIn modal...');

    // Wait a bit for content to fully load
    await new Promise(resolve => setTimeout(resolve, 500));

    // Find all scheduled post items
    // Looking for elements with date format like "jue., 8 ene. a las 16:15"
    const postItems = modal.querySelectorAll('[class*="scheduled-post"], .artdeco-list__item');
    const importedPosts = [];

    // Also try to find by date pattern in the modal
    const allTextElements = modal.querySelectorAll('div, span, p');
    const datePattern = /(?:Publicación:?\s*)?(\w+\.?,?\s*\d+\s*\w+\.?\s*a\s*las?\s*\d{1,2}:\d{2})/gi;

    for (const el of allTextElements) {
        const text = el.textContent || '';
        const dateMatch = text.match(datePattern);

        if (dateMatch && !el.closest('.kinked-processed')) {
            const dateText = dateMatch[0];
            // Find nearby content text (the post preview)
            const parent = el.closest('.artdeco-list__item, [class*="scheduled"]') || el.parentElement?.parentElement;
            let preview = '';

            if (parent) {
                // Get text that's NOT the date
                const allText = parent.textContent || '';
                preview = allText.replace(dateText, '').trim().substring(0, 100);
            }

            // Parse the date
            const parsedDate = parseLinkedInDateExtended(dateText);

            if (parsedDate) {
                importedPosts.push({
                    date: parsedDate,
                    preview: preview.split('\n')[0]?.trim() || 'Post programado',
                    rawDateText: dateText,
                    imported: true
                });

                // Mark as processed to avoid duplicates
                el.classList.add('kinked-processed');
            }
        }
    }

    // Save unique posts (avoid duplicates by checking rawDateText)
    if (importedPosts.length > 0) {
        const existingPosts = await getScheduledPosts();
        const existingDates = new Set(existingPosts.map(p => p.rawDateText));

        for (const post of importedPosts) {
            if (!existingDates.has(post.rawDateText)) {
                await addScheduledPost(post);
            }
        }

        console.log(`Kinkedin: Imported ${importedPosts.length} scheduled posts`);
    }
}

// Extended date parser for LinkedIn's format
function parseLinkedInDateExtended(dateText) {
    // Formats: "jue., 8 ene. a las 16:15" or "Publicación: vie., 23 ene. a las 16:15"
    try {
        const now = new Date();
        const currentYear = now.getFullYear();

        // Extract day number
        const dayMatch = dateText.match(/(\d{1,2})/);
        // Extract month
        const monthPatterns = {
            'ene': 0, 'feb': 1, 'mar': 2, 'abr': 3, 'may': 4, 'jun': 5,
            'jul': 6, 'ago': 7, 'sep': 8, 'oct': 9, 'nov': 10, 'dic': 11,
            'jan': 0, 'apr': 3, 'aug': 7, 'dec': 11
        };

        let month = null;
        for (const [key, value] of Object.entries(monthPatterns)) {
            if (dateText.toLowerCase().includes(key)) {
                month = value;
                break;
            }
        }

        // Extract time
        const timeMatch = dateText.match(/(\d{1,2}):(\d{2})/);

        if (dayMatch && month !== null && timeMatch) {
            const day = parseInt(dayMatch[1]);
            const hours = parseInt(timeMatch[1]);
            const minutes = parseInt(timeMatch[2]);

            const scheduled = new Date(currentYear, month, day, hours, minutes, 0, 0);

            // If date is in the past, assume next year
            if (scheduled < now) {
                scheduled.setFullYear(currentYear + 1);
            }

            return scheduled.toISOString();
        }
    } catch (e) {
        console.log('Kinkedin: Date parse error', e);
    }

    return null;
}

// Handle when post modal appears
function handleModalAppeared(modal) {
    console.log('Kinkedin: Post modal detected');

    // Continuously watch for scheduling state changes
    const checkState = setInterval(() => {
        const scheduleBtn = modal.querySelector('.share-actions__scheduled-post-btn');

        // Inject calendar button if not already there
        if (scheduleBtn && !modal.querySelector('.kinked-calendar-btn')) {
            const calendarBtn = createCalendarButton();
            scheduleBtn.parentElement.insertBefore(calendarBtn, scheduleBtn);
            console.log('Kinkedin: Calendar button injected');
        }

        // NEW: Use the CORRECT selector for the schedule info container
        const scheduleInfoContainer = modal.querySelector('.share-creation-state__schedule-info-container');

        // Also look for the final "Programar" button (replaces "Publicar")
        const programarBtn = modal.querySelector('.share-actions__primary-action');
        const isProgramarMode = programarBtn &&
            (programarBtn.textContent?.includes('Programar') || programarBtn.textContent?.includes('Schedule'));

        if (isProgramarMode && scheduleInfoContainer) {
            // We're in scheduled mode!
            console.log('Kinkedin: Schedule mode detected, container found');

            // If we haven't already set up the listener
            if (!modal.dataset.kinkedinScheduleWatching) {
                modal.dataset.kinkedinScheduleWatching = 'true';

                programarBtn.addEventListener('click', () => {
                    // Get the date text NOW (at click time, not before)
                    const container = modal.querySelector('.share-creation-state__schedule-info-container');
                    let dateText = '';

                    if (container) {
                        // The container has: SVG + text node + Editar button
                        // Get only the text content, which includes "Publicación: mar, 6 ene a las 16:45"
                        const fullText = container.textContent || '';
                        // Extract the date part
                        const dateMatch = fullText.match(/Publicación:?\s*([\w,\.]+\s*\d+\s*\w+\.?\s*a\s*las?\s*\d{1,2}:\d{2})/i);
                        if (dateMatch) {
                            dateText = dateMatch[0];
                        } else {
                            // Fallback: just use the full text
                            dateText = fullText.replace('Editar', '').trim();
                        }
                    }

                    const editor = modal.querySelector('.ql-editor');
                    const preview = editor ? editor.textContent.substring(0, 100) : '';

                    console.log('Kinkedin: Programar clicked! Date:', dateText, 'Preview:', preview);

                    if (dateText) {
                        addScheduledPost({
                            date: parseLinkedInDateExtended(dateText) || new Date().toISOString(),
                            preview: preview,
                            rawDateText: dateText
                        });
                    } else {
                        // Fallback: save anyway with unknown date
                        addScheduledPost({
                            date: new Date().toISOString(),
                            preview: preview,
                            rawDateText: 'Fecha no detectada'
                        });
                        console.log('Kinkedin: Date not detected, saved with fallback');
                    }
                }, { once: true });

                console.log('Kinkedin: Watching Programar button');
            }
        }
    }, 500);

    // Clear interval when modal closes
    const modalObserver = new MutationObserver(() => {
        if (!document.body.contains(modal)) {
            clearInterval(checkState);
            modalObserver.disconnect();
            console.log('Kinkedin: Modal closed, stopped watching');
        }
    });
    modalObserver.observe(document.body, { childList: true, subtree: true });

    // Safety timeout
    setTimeout(() => clearInterval(checkState), 60000);
}

// Initialize the calendar module
function initCalendarModule() {
    console.log('Kinkedin: Calendar module initialized');
    observeSchedulingModal();
}

// Export for use in content.js
window.kinkedinCalendar = {
    init: initCalendarModule,
    showCalendar: showCalendarPopup,
    getScheduledPosts,
    addScheduledPost,
    deleteScheduledPost,
    importFromModal: importScheduledPostsFromModal
};
